from django.contrib import admin
from home.models import Speak

# Register your models here.
admin.site.register(Speak)