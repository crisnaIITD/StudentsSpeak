/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['home/templates'],
  theme: {
    extend: {},
  },
  plugins: [],
}

